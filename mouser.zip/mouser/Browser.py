import pandas as pd
from random import choice
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait

from constants import CHROME_DRIVER


class Browser(object):
    """Selenium Driver to initiate"""
    @staticmethod
    def readcsv():
        proxies, useragent = pd.read_csv('ip_list.csv'), pd.read_csv('useragent.csv')
        ips, ua = proxies.IP_PORT.values.tolist(), useragent.UserAgent.values.tolist()
        return choice(ips), choice(ua)

    @staticmethod
    def start():
        """Start the Selenium driver and return driver and wait object"""
        chrome_options = webdriver.ChromeOptions()
        ip, ua = Browser.readcsv()

        chrome_options.add_argument("--disable-bundled-ppapi-flash")
        chrome_options.add_argument("--incognito")
        # chrome_options.add_argument("user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36")
        chrome_options.add_argument("--disable-plugins-discovery")
        chrome_options.add_argument('--proxy-server=http://%s' % ip)
        chrome_options.add_argument('--user-agent=%s' % ua)
        driver = webdriver.Chrome(executable_path=CHROME_DRIVER, chrome_options=chrome_options)
        driver.delete_all_cookies()
        wait = WebDriverWait(driver, 30)
        return driver, wait

    @staticmethod
    def stop(driver):
        return driver.quit()

