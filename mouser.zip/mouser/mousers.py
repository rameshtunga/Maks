from Browser import Browser
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException


URL = 'https://www.mouser.com/Passive-Components/Capacitors/Ceramic-Capacitors/MLCCs-Multilayer-Ceramic-Capacitors/_/N-bkrdaZgjdhub?P=1z0zlseZ1z0znw3Z1z0izcaZ1z0zlft'
browser = Browser()
driver, wait = browser.start()
driver.get(URL)

