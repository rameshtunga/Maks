# -*- coding: utf-8 -*-
import scrapy
from datetime import datetime as dt

class RobertHalfAllSpider(scrapy.Spider):
    name = 'roberthalf-all'
    allowed_domains = ['www.roberthalf.com']
    start_urls = ['https://www.roberthalf.com/ajax/jobs?maxJobs=1000000']
    def parse(self, response):
        # For each job result in the index extract data
        for job_result in response.css('div.row.rh-job-result-table__row'):
            # Get the link to the job page 
            job_url = job_result.css('a.rh-job-result-table__job-title::attr(href)').extract_first()
            # Remove page argument from joined url
            job_url = response.urljoin(job_url).split('?page=')[0]
            # Get basic data about the job
            job_result_data = {
                'type' : 'job_result',
                'job_url' : job_url,
                'job_title' : job_result.css('a.rh-job-result-table__job-title::text').extract_first().strip(),
                'location' : job_result.css('span.rh-job-result-table__location::text').extract_first(), 
                'salary' : job_result.css('span.rh-job-result-table__salary::text').extract_first(),
                'emptype' : job_result.css('span.rh-job-result-table__emptype::text').extract_first(),
                'postdate' : job_result.css('span.rh-job-result-table__postdate::text').extract_first()
            }
            yield job_result_data
            # Follow link to job ad page
            if job_url:
                yield scrapy.Request(url = job_url, callback = self.parse_job)

        # Follow pagination link
        next_page_url = response.css('li.rh-pager__list-item.pager__item--next > a.rh-pager__link--arrow::attr(href)').extract_first()
        if next_page_url:
            next_page_url = response.urljoin(next_page_url)
            yield scrapy.Request(url = next_page_url, callback = self.parse)

    def parse_job(self, response):
        # Get data from single items 
        job_data = {
            'update_timestamp':  dt.now().strftime('%Y-%m-%d %H:%M:%S'),
            'type' : 'job_data',
            'job_url' : response.url,
            'job_title' : response.css('label.rh-job-page__title::text').extract_first(),
            'job_description' : response.css('div.rh-job-page__description > div.rh-job-page__job-info-text::text').extract(),
            'job_requirements' : response.css('div.rh-job-page__requirements > div.rh-job-page__job-info-text::text').extract(),
            'job_boilerplate' : response.css('div.rh-job-page__boilerplate > div.rh-job-page__job-info-text::text').extract(),
            'applicant_count' : int(response.css('label.rh-job-page__applicant-counter-count::text').extract_first()),
            'view_count' : int(response.css('label.rh-job-page__view-counter-count::text').extract_first()),
        }
        # Convert job properties into one dict 
        rows = response.css('div.rh-job-page.clearfix  div.clearfix.row')
        desc_keys = [x.lower().replace(' ', '_').replace(':', '').strip() for x in rows.css('p.rh-job-page__job-label::text').extract()]
        desc_values = [x.strip() for x in rows.css('p.rh-job-page__job-property::text').extract()]
        desc_dict = dict(zip(desc_keys, desc_values))
        # Merge with previous items
        job_data.update(desc_dict)
        yield job_data
        # Follow links to related jobs
        for other_job_url in response.css('div.rh-job-result-sidebar__list a.rh-job-result-sidebar__job-title::attr(href)').extract():
            if other_job_url:
                yield scrapy.Request(url = response.urljoin(other_job_url), callback = self.parse_job)
