# -*- coding: utf-8 -*-
import scrapy
from datetime import datetime as dt

class RobertHalfJobsSpider(scrapy.Spider):
    name = 'roberthalf-jobs'
    allowed_domains = ['www.roberthalf.com']
    max_jobs = 50000
    start_urls = ['https://www.roberthalf.com/ajax/jobs?maxJobs={}'.format(max_jobs)]
    def parse(self, response):
        # For each job ad get job url 
        for job_url in response.css('a.rh-job-result-table__job-title::attr(href)').extract():
            # Remove page argument from joined url
            job_url = response.urljoin(job_url).split('?page=')[0]
            # Follow link to job ad page
            yield scrapy.Request(url = job_url, callback = self.parse_job)

        # Follow pagination links
        for next_page_url in response.css('ul.rh-pager__list a::attr(href)').extract():
            next_page_url = response.urljoin(next_page_url)
            yield scrapy.Request(url = next_page_url, callback = self.parse)

    def parse_job(self, response):
        # Get data from single items 
        job_data = {
            'update_timestamp':  dt.now().strftime('%Y-%m-%d %H:%M:%S'),
            'job_url' : response.url,
            'job_title' : response.css('label.rh-job-page__title::text').extract_first(),
            'job_description' : response.css('div.rh-job-page__description > div.rh-job-page__job-info-text::text').extract(),
            'job_requirements' : response.css('div.rh-job-page__requirements > div.rh-job-page__job-info-text::text').extract(),
            'job_boilerplate' : response.css('div.rh-job-page__boilerplate > div.rh-job-page__job-info-text::text').extract(),
            'applicant_count' : int(response.css('label.rh-job-page__applicant-counter-count::text').extract_first()),
            'view_count' : int(response.css('label.rh-job-page__view-counter-count::text').extract_first()),
        }
        # Convert job properties into one dict 
        rows = response.css('div.rh-job-page.clearfix  div.clearfix.row')
        desc_keys = [x.lower().replace(' ', '_').replace(':', '').strip() for x in rows.css('p.rh-job-page__job-label::text').extract()]
        desc_values = [x.strip() for x in rows.css('p.rh-job-page__job-property::text').extract()]
        desc_dict = dict(zip(desc_keys, desc_values))
        # Merge with previous items
        job_data.update(desc_dict)
        yield job_data
        # Follow links to related jobs
        for other_job_url in response.css('div.rh-job-result-sidebar__list a.rh-job-result-sidebar__job-title::attr(href)').extract():
            if other_job_url:
                yield scrapy.Request(url = response.urljoin(other_job_url), callback = self.parse_job)