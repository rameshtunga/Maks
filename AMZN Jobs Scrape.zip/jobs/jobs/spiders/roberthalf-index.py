# -*- coding: utf-8 -*-
import scrapy

class RobertHalfSpider(scrapy.Spider):
    name = 'roberthalf-index'
    allowed_domains = ['www.roberthalf.com']
    max_jobs = 50000
    start_urls = ['https://www.roberthalf.com/ajax/jobs?maxJobs={}'.format(max_jobs)]
    def parse(self, response):
        # For each job result in the index extract data
        for job_result in response.css('div.row.rh-job-result-table__row'):
            # Get the link to the job page 
            job_url = job_result.css('a.rh-job-result-table__job-title::attr(href)').extract_first()
            # Remove page argument from joined url
            job_url = response.urljoin(job_url).split('?page=')[0]
            # Get basic data about the job
            job_index_data = {
                'job_url' : job_url,
                'job_title' : job_result.css('a.rh-job-result-table__job-title::text').extract_first().strip(),
                'location' : job_result.css('span.rh-job-result-table__location::text').extract_first(), 
                'salary' : job_result.css('span.rh-job-result-table__salary::text').extract_first(),
                'emptype' : job_result.css('span.rh-job-result-table__emptype::text').extract_first(),
                'postdate' : job_result.css('span.rh-job-result-table__postdate::text').extract_first()
            }
            yield job_index_data

        # Follow pagination links
        for next_page_url in response.css('ul.rh-pager__list a::attr(href)').extract():
            next_page_url = response.urljoin(next_page_url)
            yield scrapy.Request(url = next_page_url, callback = self.parse)