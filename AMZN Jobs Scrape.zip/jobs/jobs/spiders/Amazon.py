# -*- coding: utf-8 -*-
import scrapy
import json
import re
from datetime import datetime
from datetime import date, timedelta
from lxml import html

class AmazonSpider(scrapy.Spider):
    name = "Amazon"
    allowed_domains = ["amazon.com", "amazon.jobs"]
    start_urls = ['https://www.amazon.jobs/en/job_categories']

    def parse(self, response):
        # Extract categories
        xpt_l_categories = '//div[@id="job-categories"]//div[@data-react-class="Tiles"]/@data-react-props'
        l_categories = response.xpath(xpt_l_categories).extract_first()
        # load it with json and extract each category inside the items key
        l_categories = json.loads(l_categories)['items']
        total = 0
        for category in l_categories:
            # Extract the number of open positions in 'details' key
            openpos = re.findall('[0-9]+(?= open job)', category['details'][0])[0]
            total += int(openpos)

        for category in l_categories:
            # Extract the number of open positions in 'details' key
            openpos = re.findall('[0-9]+(?= open job)', category['details'][0])[0]
            # Extract the category name from the link
            category_title = category['title']
            catname = category['link'].split('/')[-1]
            catlink = 'https://www.amazon.jobs' +\
            '/en/search?base_query=&' +\
            '&result_limit={}&offset=0&'.format(openpos) +\
            'sort=relevant&category%5B%5D={}&cache'.format(catname)
            # Payload of the xmlhttp request
            data = '{{"category[]":"{}", "result_limit":{}, "offset":0,' +\
            '"sort": "relevant", "animate":"false"}}'
            # XMLHttpRequest simulation
            yield scrapy.Request(catlink, callback= self.parse_category,
                meta={'category_title' : category_title},
                method='GET',
                headers={
                    'Accept' : 'application/json, text/javascript, */*; q=0.01',
                    'Content-Type' : 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body= json.dumps(data.format(catname, openpos))
            )

    def parse_category(self, response):
        json_response = json.loads(response.body)
        item = dict()
        item['total_jobs_in_this_category'] = json_response['hits']
        item['parse_date'] = date.today().strftime('%Y-%m-%d')
        # item['link'] = response.url   # this url for debugging
        for job in json_response['jobs']:
            item['business_category'] = job['business_category']
            item['category_title'] = response.meta['category_title']
            item['id'] = job['id_icims']
            item['country'] = job['country_code']
            item['city'] = job['city']
            item['state'] = job['state']
            item['primary_search_label'] = job['primary_search_label']
            item['basic_qualifications'] = self._parse_htmltags(job['basic_qualifications'])
            item['preferred_qualifications'] = self._parse_htmltags(job['preferred_qualifications'])
            item['location'] = job['location']
            item['company_name'] = job['company_name']
            item['description'] = self._parse_htmltags(job['description'])
            item['job_category'] = job['job_category']
            item['posted_date'] = datetime.strptime(job['posted_date'], '%B %d, %Y')
            item['job_path'] = 'https://www.amazon.jobs' + job['job_path']
            item['title'] = job['title']
            item['description_short'] = job['description_short']
            yield item

    def _parse_htmltags(self, rawhtml):
        if (rawhtml == None):
            return ""
        """Parse rawhtml removing <br> and bullets. Preserves important chars
        present in foreign languages, ie: asian job posts"""
        # Removes all <br> tags from the rawhtml
        nobrtext = re.sub('<br?>', '\n', rawhtml)
        nobulltext = re.sub('\xb7|\u2022', '', nobrtext)
        text = html.fromstring(nobulltext).text_content()
        # Remove all bullets
        return text
